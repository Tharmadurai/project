import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MatDialogModule,MatSidenavModule,MatListModule, MatButtonModule, MatCardModule, MatFormFieldModule, MatNativeDateModule,MatMenuModule, MatTabsModule, MatToolbarModule, MatInputModule, MatTooltipModule, MatSnackBarModule,MatBadgeModule,MatStepperModule,MatTableModule,MatPaginatorModule, MatIconModule  } from '@angular/material';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormControl, FormGroup } from '@angular/forms';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';

import { HomeComponent } from './home/home.component';
import { LoginModelComponent } from './Model/login-model/login-model.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeHeaderComponent } from './Layouts/home-header/home-header.component';
import { HomeFooterComponent } from './Layouts/home-footer/home-footer.component';
import { HomeLayoutComponent } from './Layouts/home-layout/home-layout.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { MainNavComponent } from './Common/sideNavBar/main-nav/main-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { CountryComponent } from './admin/general/locationManagement/country/country.component';
import { StateComponent } from './admin/general/locationManagement/state/state.component';
import { CityComponent } from './admin/general/locationManagement/city/city.component';
import { BankComponent } from './admin/general/bank/bank.component';
import { RoleComponent } from './admin/general/role/role.component';
import { CustomerDetailsComponent } from './admin/customer-details/customer-details.component';
import { FareEstimationComponent } from './admin/fare-estimation/fare-estimation.component';

import { TieupcollectioncenterComponent } from './admin/tieups/tieupcollectioncenter/tieupcollectioncenter.component';
import { TieupretailerComponent } from './admin/tieups/tieupretailer/tieupretailer.component';
import { TieupinventoryComponent } from './admin/tieups/tieupinventory/tieupinventory.component';
import { SupplierdetailsComponent } from './admin/collectioncenter/supplierdetails/supplierdetails.component';
import { RevenueComponent } from './admin/financeandforecast/revenue/revenue.component';
import { ExpenseComponent } from './admin/financeandforecast/expense/expense.component';
import { DirectCostComponent } from './admin/financeandforecast/direct-cost/direct-cost.component';
import { PermComponent } from './admin/financeandforecast/perm/perm.component';
import { LabourComponent } from './admin/retailers/labour/labour.component';
import { OrderComponent } from './admin/retailers/order/order.component';
import { FrequentlycustomerComponent } from './admin/retailers/frequentlycustomer/frequentlycustomer.component';
import { RetailerinventoryComponent } from './admin/retailers/retailerinventory/retailerinventory.component';
import { AddemployeesComponent } from './admin/employeesregistration/addemployees/addemployees.component';
import { EmployeepermissionComponent } from './admin/employeesregistration/employeepermission/employeepermission.component';
import { CategoriestypeComponent } from './admin/general/categoriesmanagement/categoriestype/categoriestype.component';
import { SubcategoriesComponent } from './admin/general/categoriesmanagement/subcategories/subcategories.component';
import { CatagoriesComponent } from './admin/general/categoriesmanagement/catagories/catagories.component';
import {MatDatepickerModule} from '@angular/material/datepicker';


const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: HomeComponent
  },
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginModelComponent,
    HomeHeaderComponent,
    HomeFooterComponent,
    HomeLayoutComponent,
    AdminDashboardComponent,
    MainNavComponent,
    CountryComponent,
    StateComponent,
    CityComponent,
    BankComponent,
    RoleComponent,
    CustomerDetailsComponent,
    FareEstimationComponent,
    
    TieupcollectioncenterComponent,
    TieupretailerComponent,
    TieupinventoryComponent,
    SupplierdetailsComponent,
    RevenueComponent,
    ExpenseComponent,
    DirectCostComponent,
    PermComponent,
    LabourComponent,
    OrderComponent,
    FrequentlycustomerComponent,
    RetailerinventoryComponent,
    AddemployeesComponent,
    EmployeepermissionComponent,
    CategoriestypeComponent,
    SubcategoriesComponent,
    CatagoriesComponent,
   
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    RouterModule,
    MatDialogModule,
    MatButtonModule,
    MatCardModule,
    MatMenuModule,
    MatToolbarModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule,
    MatBadgeModule,
    MatStepperModule,
    MatTableModule,
    MatSidenavModule,FormsModule, ReactiveFormsModule,MatNativeDateModule,
    MatPaginatorModule,
    MatListModule,
    MatSnackBarModule,MatDatepickerModule,
    RouterModule.forRoot(routes),
    LayoutModule,
    MatIconModule,
  ],
  exports: [RouterModule],
  entryComponents:[
    LoginModelComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
