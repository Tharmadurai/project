import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplierdetails',
  templateUrl: './supplierdetails.component.html',
  styleUrls: ['./supplierdetails.component.css']
})
export class SupplierdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
