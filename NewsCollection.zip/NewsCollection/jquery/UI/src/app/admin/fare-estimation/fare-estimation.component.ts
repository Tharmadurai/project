import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fare-estimation',
  templateUrl: './fare-estimation.component.html',
  styleUrls: ['./fare-estimation.component.css']
})
export class FareEstimationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
