import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FareEstimationComponent } from './fare-estimation.component';

describe('FareEstimationComponent', () => {
  let component: FareEstimationComponent;
  let fixture: ComponentFixture<FareEstimationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FareEstimationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FareEstimationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
