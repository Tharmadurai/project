import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FrequentlycustomerComponent } from './frequentlycustomer.component';

describe('FrequentlycustomerComponent', () => {
  let component: FrequentlycustomerComponent;
  let fixture: ComponentFixture<FrequentlycustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FrequentlycustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FrequentlycustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
