import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailerinventoryComponent } from './retailerinventory.component';

describe('RetailerinventoryComponent', () => {
  let component: RetailerinventoryComponent;
  let fixture: ComponentFixture<RetailerinventoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetailerinventoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetailerinventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
