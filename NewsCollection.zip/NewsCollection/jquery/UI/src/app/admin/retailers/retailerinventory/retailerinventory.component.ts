import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailerinventory',
  templateUrl: './retailerinventory.component.html',
  styleUrls: ['./retailerinventory.component.css']
})
export class RetailerinventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
