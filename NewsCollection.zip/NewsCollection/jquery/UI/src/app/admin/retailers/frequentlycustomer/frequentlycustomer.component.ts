

import { Component, OnInit } from '@angular/core';
import { ViewChild} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
// import { NewComponent } from '../new/new.component';
import {MatPaginator, MatTableDataSource} from '@angular/material';

@Component({
    selector: 'app-frequentlycustomer',
    templateUrl: './frequentlycustomer.component.html',
    styleUrls: ['./frequentlycustomer.component.css']
  })
  export class FrequentlycustomerComponent implements OnInit {
  


  displayedColumns: string[] = ['ID','Name','MobileNumber','EmailID', 'Action'];
 
    dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);  
    @ViewChild(MatPaginator) paginator: MatPaginator;
 

constructor(){ }
  
    // this.dialog.open(NewComponent);
  
  
  ngOnInit() {    this.dataSource.paginator = this.paginator;

  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    
  }
  }
}

  export interface PeriodicElement {
    Name: string;
    MobileNumber: Number;
  ID: string;
  EmailID:string;
    action:string;
  }
  
  const ELEMENT_DATA: PeriodicElement[] = [
    {ID:'4',Name:'swathi', MobileNumber:9938989897,EmailID:'svrraikar@gmail.com', action:''},
    {ID:'4',Name:'swathi', MobileNumber:9938989897,EmailID:'svrraikar@gmail.com', action:''},
    {ID:'4',Name:'bavya', MobileNumber:9938989897,EmailID:'svrraikar@gmail.com', action:''},
    {ID:'4',Name:'bavya', MobileNumber:9938989897,EmailID:'svrraikar@gmail.com', action:''},
    {ID:'4',Name:'pooja', MobileNumber:9938989897,EmailID:'svrraikar@gmail.com', action:''},
    {ID:'4',Name:'pooja', MobileNumber:9938989897,EmailID:'svrraikar@gmail.com', action:''},


    
  ];

  