// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-perm',
//   templateUrl: './perm.component.html',
//   styleUrls: ['./perm.component.css']
// })
// export class PermComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
import { OnInit } from '@angular/core';



import { Component, ViewChild} from '@angular/core';
import {MatPaginator, MatTableDataSource} from '@angular/material';
export interface PeriodicElement {
  ID:string;
  Source: string;
  Action:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {ID:'122',Source: 'Trainer',Action:''},
  {ID:'565',Source: 'Staff',Action:''},
  {ID:'565',Source: 'Office Maintainance',Action:''},
  {ID:'230',Source: 'Retailer',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'565',Source: 'Localist',Action:''}
  
  
  
];
@Component({
  selector: 'app-perm',
  templateUrl: './perm.component.html',
  styleUrls: ['./perm.component.css']
})
export class PermComponent implements OnInit {

  

displayedColumns: string[] = ['ID','Source','Action'];
 
    dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);  
    @ViewChild(MatPaginator) paginator: MatPaginator;


ngOnInit() {this.dataSource.paginator = this.paginator;

}
applyFilter(filterValue: string) {
  this.dataSource.filter = filterValue.trim().toLowerCase();

  if (this.dataSource.paginator) {
    this.dataSource.paginator.firstPage();
  
}
}
}
  

