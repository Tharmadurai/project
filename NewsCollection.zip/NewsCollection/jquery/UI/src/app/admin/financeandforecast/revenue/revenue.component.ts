// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-revenue',
//   templateUrl: './revenue.component.html',
//   styleUrls: ['./revenue.component.css']
// })
// export class RevenueComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { Component, ViewChild} from '@angular/core';
import {MatPaginator, MatTableDataSource} from '@angular/material';
export interface PeriodicElement {
  ID:string;
  Source: string;
  Action:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {ID:'122',Source: 'Customer',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'230',Source: 'Retailer',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'565',Source: 'Localist',Action:''}
  
  
  
];
@Component({
  selector: 'app-revenue',
  templateUrl: './revenue.component.html',
  styleUrls: ['./revenue.component.css']
})
export class RevenueComponent {

  

displayedColumns: string[] = ['ID','Source','Action'];
 
    dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);  
    @ViewChild(MatPaginator) paginator: MatPaginator;


ngOnInit() {this.dataSource.paginator = this.paginator;

}
applyFilter(filterValue: string) {
  this.dataSource.filter = filterValue.trim().toLowerCase();

  if (this.dataSource.paginator) {
    this.dataSource.paginator.firstPage();
  
}
}
}
  

