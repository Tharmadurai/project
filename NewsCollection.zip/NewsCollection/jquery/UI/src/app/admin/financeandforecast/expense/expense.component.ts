
import {OnInit } from '@angular/core';


import { Component, ViewChild} from '@angular/core';
import {MatPaginator, MatTableDataSource} from '@angular/material';
export interface PeriodicElement {
  ID:string;
  Source: string;
  Action:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {ID:'122',Source: 'Customer',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'230',Source: 'Retailer',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'565',Source: 'Localist',Action:''},
  {ID:'565',Source: 'Localist',Action:''}
  
  
  
];

@Component({
  selector: 'app-expense',
  templateUrl: './expense.component.html',
  styleUrls: ['./expense.component.css']
})
export class ExpenseComponent implements OnInit {

  

displayedColumns: string[] = ['ID','Source','Action'];
 
    dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);  
    @ViewChild(MatPaginator) paginator: MatPaginator;


ngOnInit() {this.dataSource.paginator = this.paginator;

}
applyFilter(filterValue: string) {
  this.dataSource.filter = filterValue.trim().toLowerCase();

  if (this.dataSource.paginator) {
    this.dataSource.paginator.firstPage();
  
}
}
}
  
