
import { Component, OnInit } from '@angular/core';
import { ViewChild} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
// import { NewComponent } from '../new/new.component';
import {MatPaginator, MatTableDataSource} from '@angular/material';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {

  displayedColumns: string[] = ['Name','MobileNumber', 'EmailID', 'RequestedDate', 'Action'];
 
    dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);  
    @ViewChild(MatPaginator) paginator: MatPaginator;
 

constructor(){ }
  
    // this.dialog.open(NewComponent);
  
  
  ngOnInit() {    this.dataSource.paginator = this.paginator;

  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    
  }
  }
}

  export interface PeriodicElement {
    Name: string;
    MobileNumber: Number;
    EmailID: string;
    RequestedDate:string;
    action:string;
  }
  
  const ELEMENT_DATA: PeriodicElement[] = [
    {Name:'sangeeta',MobileNumber: 9938989897, EmailID: 'svrraikar@gmail.com', RequestedDate:'2020-1-21',action:''},
    {Name:'sanjana',MobileNumber: 9938989897, EmailID: 'svrraikar@gmail.com', RequestedDate:'2020-1-21',action:''},

    {Name:'sankranti',MobileNumber: 9938989897, EmailID: 'svrraikar@gmail.com', RequestedDate:'2020-1-21',action:''},
    {Name:'sarala',MobileNumber: 9938989897, EmailID: 'svrraikar@gmail.com', RequestedDate:'2020-1-21',action:''},
    {Name:'sangeeta',MobileNumber: 9938989897, EmailID: 'svrraikar@gmail.com', RequestedDate:'2021-1-22',action:''},
    {Name:'sangeeta',MobileNumber: 9938989897, EmailID: 'svrraikar@gmail.com', RequestedDate:'2020-1-24',action:''},

    
    
  ];

  
