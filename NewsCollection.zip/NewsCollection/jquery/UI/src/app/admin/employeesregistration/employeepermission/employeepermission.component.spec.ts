import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeepermissionComponent } from './employeepermission.component';

describe('EmployeepermissionComponent', () => {
  let component: EmployeepermissionComponent;
  let fixture: ComponentFixture<EmployeepermissionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeepermissionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeepermissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
