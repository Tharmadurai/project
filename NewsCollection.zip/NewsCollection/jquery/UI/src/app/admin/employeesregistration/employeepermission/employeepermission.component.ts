import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeepermission',
  templateUrl: './employeepermission.component.html',
  styleUrls: ['./employeepermission.component.css']
})
export class EmployeepermissionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
