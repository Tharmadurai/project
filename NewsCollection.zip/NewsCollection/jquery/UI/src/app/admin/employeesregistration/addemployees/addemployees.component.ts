import { Component, OnInit, Inject,ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MustMatch } from './helpers/must-match.validators';
import * as $ from 'jquery';
declare var $: any;
// import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {
  MatSnackBar,
  MatSnackBarConfig,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material';
// export interface DialogData {

// }

@Component({
  selector: 'app-addemployees',
  templateUrl: './addemployees.component.html',
  styleUrls: ['./addemployees.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class AddemployeesComponent implements OnInit {
  tabLoadTimes: Date[] = [];

  getTimeLoaded(index: number) {
    if (!this.tabLoadTimes[index]) {
      this.tabLoadTimes[index] = new Date();
    }

    return this.tabLoadTimes[index];
  }

  
  
  message: string = 'submit successfully';
  actionButtonLabel: string = 'Thank you';
  action: boolean = true;
  setAutoHide: boolean = true;
  autoHide: number = 3000;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  
  acceptTerms: boolean = false;



  [x: string]: any;
  registerForm: FormGroup;
  submitted = false;
model:any={}

  constructor(private formBuilder: FormBuilder,public snackBar: MatSnackBar) { 
    function randomNumber(min, max) {
      return Math.ceil(Math.random() * (max - min) + min);
      }
      var otp = 1234567890;
      $(document).ready(function(){
      $('.otp').hide();
      $('.check').hide();
      $('.generate').click(function()
      {
        otp= randomNumber('1000','9999');
      var number = $('.number').val();
      $('.number').attr('disabled','disabled');
      $('.otp').show();
      $('.check').show();
      $('.generate').hide();
      alert(otp);
      /// Code to send OTP
      });
      $('.check').click(function(){
      var user_otp = $('.otp').val();
      if(otp==user_otp){
      alert('Succcess');
      }else{
      alert('Error');
      }
      });
      });
    }


  ngOnInit() {
//   
  //   this.registerForm = this.formBuilder.group({
  //     firstName: ['', Validators.required],
  //     lastName: ['', Validators.required],
  //     email: ['', [Validators.required, Validators.email]],
  //     password: ['', [Validators.required, Validators.minLength(6)]]
  // });
  this.registerForm = this.formBuilder.group({
    title: ['', Validators.required],
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    mobile:['',[Validators.required,Validators.minLength(10)]],
    otp:['',[Validators.required,Validators.maxLength(4)]],
    city:['', Validators.required],
     state:['',Validators.required],
    zip:['', Validators.required],
    gender:['', Validators.required],
    dateofBirth:['',Validators.required],
    password: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', Validators.required],
    acceptTerms: [false, Validators.requiredTrue],
    accountholderName:['',Validators.required],
    accountno:['',[Validators.required,Validators.minLength(12)]],
    bankname:['',Validators.required],
    branch:['',[Validators.required]],
    ifsccode:['',[Validators.required,Validators.minLength(11)]]

}, {
  
    validator: MustMatch('password', 'confirmPassword')
});
}
get f() { return this.registerForm.controls; }
onSubmit(){
  // 
  this.submitted = true;


    // stop here if form is invalid
    if (this.registerForm.valid) {
        //  return;
    

    // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value,null,4));
    // open() 
    let config = new MatSnackBarConfig();
    config.verticalPosition = this.verticalPosition;
    config.horizontalPosition = this.horizontalPosition;
    config.duration = this.setAutoHide ? this.autoHide : 0;
      //config.AcceptTerms = this.acceptTerms ? ['test'] : undefined;
   this.snackBar.open(this.message, this.action ? this.actionButtonLabel : undefined, config );
    
    }


  }
  onReset() {
    this.submitted = false;
    this.registerForm.reset();
  }
}
