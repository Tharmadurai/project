// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-bank',
//   templateUrl: './bank.component.html',
//   styleUrls: ['./bank.component.css']
// })
// export class BankComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import { Component, OnInit } from '@angular/core';
import { ViewChild} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
// import { NewComponent } from '../new/new.component';
import {MatPaginator, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.css']
})
export class BankComponent implements OnInit {
  tabLoadTimes: Date[] = [];

  getTimeLoaded(index: number) {
    if (!this.tabLoadTimes[index]) {
      this.tabLoadTimes[index] = new Date();
    }

    return this.tabLoadTimes[index];
  }



  displayedColumns: string[] = ['BankName', 'Action'];
 
    dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);  
    @ViewChild(MatPaginator) paginator: MatPaginator;
 

constructor(){ }
  
    // this.dialog.open(NewComponent);
  
  
  ngOnInit() {    this.dataSource.paginator = this.paginator;

  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    
  }
  }
}

  export interface PeriodicElement {  
    BankName: string;
    action:string;
  }
  
  const ELEMENT_DATA: PeriodicElement[] = [
    {BankName:'CANARABANK',action:''},
    {BankName:'VIJAYABANK',action:''},
    {BankName:'CANARABANK',action:''},
    {BankName:'CANARABANK',action:''},
    {BankName:'CANARABANK',action:''},
    {BankName:'CANARABANK',action:''},
    {BankName:'CANARABANK',action:''},
    {BankName:'CANARABANK',action:''},



   
    
    
  ];

  