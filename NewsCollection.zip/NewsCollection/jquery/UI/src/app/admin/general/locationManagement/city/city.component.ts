// import { Component, OnInit, ViewChild } from '@angular/core';
// import {MatPaginator} from '@angular/material/paginator';
// import {MatTableDataSource} from '@angular/material/table';


// @Component({
//   selector: 'app-city',
//   templateUrl: './city.component.html',
//   styleUrls: ['./city.component.css']
// })

// export class CityComponent implements OnInit {
//   displayedColumns: string[] = ['countryCode', 'shortName', 'name'];
//   dataSource = new MatTableDataSource<cities>(ELEMENT_DATA);

//   @ViewChild(MatPaginator) paginator: MatPaginator;



//   constructor() { }

//   ngOnInit() {
//   }



// }
// export interface cities {
//   countryCode: number;
//   shortName: string;
//   name: string;
 
// }
// const ELEMENT_DATA: cities[] = [
//   {countryCode: 91, shortName: 'IN', name:'India'},
//   {countryCode: 92, shortName: 'CH', name:'China'},
//   {countryCode: 92, shortName: 'JP', name:'Japan'}
 
// ];
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-city',
//   templateUrl: './city.component.html',
//   styleUrls: ['./city.component.css']
// })
// export class CityComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-state',
//   templateUrl: './state.component.html',
//   styleUrls: ['./state.component.css']
// })
// export class StateComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }


import { Component, OnInit } from '@angular/core';
import { ViewChild} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
// import { NewComponent } from '../new/new.component';
import {MatPaginator, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent implements OnInit {
  tabLoadTimes: Date[] = [];

  getTimeLoaded(index: number) {
    if (!this.tabLoadTimes[index]) {
      this.tabLoadTimes[index] = new Date();
    }

    return this.tabLoadTimes[index];
  }



  displayedColumns: string[] = ['City', 'Action'];
 
    dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);  
    @ViewChild(MatPaginator) paginator: MatPaginator;
 

constructor(){ }
  
    // this.dialog.open(NewComponent);
  
  
  ngOnInit() {    this.dataSource.paginator = this.paginator;

  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    
  }
  }
}

  export interface PeriodicElement {  
    City: string;
    action:string;
  }
  
  const ELEMENT_DATA: PeriodicElement[] = [
    {City:'Banglore',action:''},
    {City:'Banglore',action:''},
    {City:'Banglore',action:''},
    {City:'Banglore',action:''},
    {City:'Banglore',action:''},
    {City:'Banglore',action:''},
    {City:'Banglore',action:''},
    {City:'Banglore',action:''},


   
    
    
  ];

  
