

import { Component, OnInit } from '@angular/core';
import { ViewChild} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
// import { NewComponent } from '../new/new.component';
import {MatPaginator, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-categoriestype',
  templateUrl: './categoriestype.component.html',
  styleUrls: ['./categoriestype.component.css']
})
export class CategoriestypeComponent implements OnInit {
    tabLoadTimes: Date[] = [];

    getTimeLoaded(index: number) {
      if (!this.tabLoadTimes[index]) {
        this.tabLoadTimes[index] = new Date();
      }
  
      return this.tabLoadTimes[index];
    }

  displayedColumns: string[] = ['ID','Name', 'TypeID'];
 
    dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);  
    @ViewChild(MatPaginator) paginator: MatPaginator;
 

constructor(){ }
  
    // this.dialog.open(NewComponent);
  
  
  ngOnInit() {    this.dataSource.paginator = this.paginator;

  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    
  }
  }
}

  export interface PeriodicElement {
  ID: Number;
    Name: string;
    TypeID: Number;
  }
  
  const ELEMENT_DATA: PeriodicElement[] = [
    {ID:20,Name: 'customer', TypeID: 225},
    {ID:20,Name: 'retailer', TypeID: 225},
    {ID:20,Name: 'trainee', TypeID: 225},
    {ID:20,Name: 'management', TypeID: 225},
    {ID:20,Name: 'customer', TypeID: 225},

    
  ];

  