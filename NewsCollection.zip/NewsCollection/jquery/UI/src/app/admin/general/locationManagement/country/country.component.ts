
import { Component, OnInit } from '@angular/core';
import { ViewChild} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
// import { NewComponent } from '../new/new.component';
import {MatPaginator, MatTableDataSource} from '@angular/material';
@Component({
    selector: 'app-country',
    templateUrl: './country.component.html',
    styleUrls: ['./country.component.css']
  })
  export class CountryComponent implements OnInit {
    tabLoadTimes: Date[] = [];

    getTimeLoaded(index: number) {
      if (!this.tabLoadTimes[index]) {
        this.tabLoadTimes[index] = new Date();
      }
  
      return this.tabLoadTimes[index];
    }

  displayedColumns: string[] = ['CountryCode','ShortName', 'Country' , 'Action'];
 
    dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);  
    @ViewChild(MatPaginator) paginator: MatPaginator;
 

constructor(){ }
  
    // this.dialog.open(NewComponent);
  
  
  ngOnInit() {    this.dataSource.paginator = this.paginator;

  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    
  }
  }
}

  export interface PeriodicElement {
  CountryCode: Number;
    ShortName: string;
    Country: string;
    action:string;
    
  }
  
  const ELEMENT_DATA: PeriodicElement[] = [
    {CountryCode:20,ShortName: 'IN', Country: 'India',action:''},
    {CountryCode:93,ShortName: 'AF', Country: 'Afganistan',action:''},
    {CountryCode:20,ShortName: 'IN', Country: 'India',action:''},
    {CountryCode:20,ShortName: 'IN', Country: 'India',action:''},
    {CountryCode:20,ShortName: 'IN', Country: 'India',action:''},
    {CountryCode:20,ShortName: 'IN', Country: 'India',action:''},
    {CountryCode:20,ShortName: 'IN', Country: 'India',action:''},

    
    
  ];

  