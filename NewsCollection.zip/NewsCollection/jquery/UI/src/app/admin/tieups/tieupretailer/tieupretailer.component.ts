import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tieupretailer',
  templateUrl: './tieupretailer.component.html',
  styleUrls: ['./tieupretailer.component.css']
})
export class TieupretailerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
