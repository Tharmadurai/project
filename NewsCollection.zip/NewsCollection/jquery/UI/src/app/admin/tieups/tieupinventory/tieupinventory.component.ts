import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tieupinventory',
  templateUrl: './tieupinventory.component.html',
  styleUrls: ['./tieupinventory.component.css']
})
export class TieupinventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
