import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TieupcollectioncenterComponent } from './tieupcollectioncenter.component';

describe('TieupcollectioncenterComponent', () => {
  let component: TieupcollectioncenterComponent;
  let fixture: ComponentFixture<TieupcollectioncenterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TieupcollectioncenterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TieupcollectioncenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
