import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TieupretailerComponent } from './tieupretailer.component';

describe('TieupretailerComponent', () => {
  let component: TieupretailerComponent;
  let fixture: ComponentFixture<TieupretailerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TieupretailerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TieupretailerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
