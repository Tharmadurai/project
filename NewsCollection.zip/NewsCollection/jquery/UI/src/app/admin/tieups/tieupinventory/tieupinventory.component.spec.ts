import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TieupinventoryComponent } from './tieupinventory.component';

describe('TieupinventoryComponent', () => {
  let component: TieupinventoryComponent;
  let fixture: ComponentFixture<TieupinventoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TieupinventoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TieupinventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
