import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginModelComponent } from './Model/login-model/login-model.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { CountryComponent } from './admin/general/locationManagement/country/country.component';
import { StateComponent } from './admin/general/locationManagement/state/state.component';
import { CityComponent } from './admin/general/locationManagement/city/city.component';

import { BankComponent } from './admin/general/bank/bank.component';
import { RoleComponent } from './admin/general/role/role.component';
import { CustomerDetailsComponent } from './admin/customer-details/customer-details.component';
import { FareEstimationComponent } from './admin/fare-estimation/fare-estimation.component';
import { TieupcollectioncenterComponent } from './admin/tieups/tieupcollectioncenter/tieupcollectioncenter.component';
import { TieupretailerComponent } from './admin/tieups/tieupretailer/tieupretailer.component';
import { TieupinventoryComponent } from './admin/tieups/tieupinventory/tieupinventory.component';
import { SupplierdetailsComponent } from './admin/collectioncenter/supplierdetails/supplierdetails.component';
import { RevenueComponent } from './admin/financeandforecast/revenue/revenue.component';
import { ExpenseComponent } from './admin/financeandforecast/expense/expense.component';
import { DirectCostComponent } from './admin/financeandforecast/direct-cost/direct-cost.component';
import { PermComponent } from './admin/financeandforecast/perm/perm.component';
import { LabourComponent } from './admin/retailers/labour/labour.component';
import { OrderComponent } from './admin/retailers/order/order.component';
import { FrequentlycustomerComponent } from './admin/retailers/frequentlycustomer/frequentlycustomer.component';
import { RetailerinventoryComponent } from './admin/retailers/retailerinventory/retailerinventory.component';
import { AddemployeesComponent } from './admin/employeesregistration/addemployees/addemployees.component';
import { EmployeepermissionComponent } from './admin/employeesregistration/employeepermission/employeepermission.component';
import { CategoriestypeComponent } from './admin/general/categoriesmanagement/categoriestype/categoriestype.component';
import { SubcategoriesComponent } from './admin/general/categoriesmanagement/subcategories/subcategories.component';
import { CatagoriesComponent } from './admin/general/categoriesmanagement/catagories/catagories.component';

const routes: Routes = [

    //  Site routes goes here 
    { path:'adminDashboard',component:AdminDashboardComponent},
    { path: '', redirectTo: '/home', pathMatch: 'full'},
    { path:'home',component:HomeComponent},
    { path:'country', component:CountryComponent},
    { path:'state', component:StateComponent},
    { path:'city', component:CityComponent},
    { path:'categoriestype', component:CategoriestypeComponent},
    { path:'subcategories', component:SubcategoriesComponent},
    { path:'catgorie', component:CatagoriesComponent},
    { path:'bank', component:BankComponent},
    { path:'role', component:RoleComponent},
    { path:'customerdetails', component:CustomerDetailsComponent},
    { path:'fareestimation', component:FareEstimationComponent},
    { path:'tieupcollectioncenter', component:TieupcollectioncenterComponent},
    { path:'tieupretailer', component:TieupretailerComponent},
    { path:'tieupinventory', component:TieupinventoryComponent},
    { path:'supplierdetails', component:SupplierdetailsComponent},
    { path:'labour', component:LabourComponent},
    { path:'order', component:OrderComponent},
    { path:'frequentlycustomer', component:FrequentlycustomerComponent},
    { path:'retailerinventory', component:RetailerinventoryComponent},
    { path:'addemployees', component:AddemployeesComponent},
    { path:'employeepermission', component:EmployeepermissionComponent},
    // { path:'cat', component:EmployeepermissionComponent},
    // { path:'employeepermission', component:EmployeepermissionComponent},
    // { path:'employeepermission', component:EmployeepermissionComponent},

    { path:'role', component:RoleComponent},
    { path:'revenue', component:RevenueComponent},
    { path:'expensive', component:ExpenseComponent},
    { path:'directcost', component:DirectCostComponent},
    { path:'perm', component:PermComponent},

    { path:'fareestimation', component:FareEstimationComponent},

    // { path:'**',component:PageNotFoundComponent}
  ];
  
  @NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule {HomeComponent};
  export const routingComponents = [LoginModelComponent];
  
